(function () {



/* Exports */
Package._define("iron:location");

})();
